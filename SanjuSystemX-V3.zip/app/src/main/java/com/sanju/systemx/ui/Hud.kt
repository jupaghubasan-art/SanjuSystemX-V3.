package com.sanju.systemx.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.sanju.systemx.engine.Engine
import com.sanju.systemx.engine.WatcherService
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.sfx.Sfx
import com.sanju.systemx.sfx.SfxHub
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState

/** The landscape Game Space dashboard. Reads Engine state 4x per second, only while visible. */
class Hud(private val a: Activity, private val prefs: Prefs) {
    val view = LinearLayout(a)

    private val shizukuChip = a.tv("SHIZUKU", 11f, Pal.TEXT, true)
    private val gameChip = a.tv("GAME", 11f, Pal.TEXT, true)
    private val fpsTarget = Row(a, "TARGET")
    private val fpsBig = a.tv("-", 54f, Pal.TEXT, true)
    private val fpsStatus = Row(a, "STATUS")
    private val fpsNote = a.tv("", 10f, Pal.SUB)
    private val graph = GraphView(a)
    private val logView = a.tv("", 10f, Pal.SUB)

    private val hzNow = Row(a, "CURRENT DISPLAY")
    private val hzReq = Row(a, "REQUESTED")
    private val hzAct = Row(a, "ACTUAL")
    private val hzStat = Row(a, "STATUS")
    private val hzModes = a.tv("", 10f, Pal.SUB)

    private val cpuUse = Row(a, "USAGE")
    private val cpuFreq = Row(a, "FREQUENCY")
    private val cpuTemp = Row(a, "TEMPERATURE")
    private val gpuUse = Row(a, "USAGE")
    private val gpuFreq = Row(a, "FREQUENCY")
    private val gpuTemp = Row(a, "TEMPERATURE")
    private val gpuBoost = Row(a, "GPU BOOST")
    private val battTemp = Row(a, "BATTERY")
    private val modeRow = Row(a, "GAME MODE HINT")
    private val touchRow = Row(a, "TOUCH RESPONSE")
    private val appliedRow = Row(a, "PROFILE")

    private val gpuTargetTxt = a.tv("", 12f, Pal.TEXT, true)
    private var shownFps = 0f
    private var lastSeq = -1
    private val need = "SHIZUKU REQUIRED"

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setBackgroundColor(Pal.BG)
        view.setPadding(a.dp(14), a.dp(8), a.dp(14), a.dp(8))

        // ---- top bar ----
        val top = LinearLayout(a)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = a.tv("SANJUSYSTEMX", 20f, Pal.RED, true)
        title.letterSpacing = 0.12f
        top.addView(title)
        val sub = a.tv("  V3  GAME SPACE", 12f, Pal.TEXT, true)
        top.addView(sub)
        top.addView(View0(), LinearLayout.LayoutParams(0, 1, 1f))
        shizukuChip.setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5))
        gameChip.setPadding(a.dp(10), a.dp(5), a.dp(10), a.dp(5))
        top.addView(shizukuChip)
        top.addView(gameChip, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = a.dp(8) })
        view.addView(top)

        // ---- body ----
        val body = LinearLayout(a)
        body.orientation = LinearLayout.HORIZONTAL
        view.add(body, 6, 1f)

        // left: FPS monitor
        val fpsP = a.panel("FPS MONITOR")
        fpsP.add(fpsTarget.view, 4)
        fpsBig.gravity = Gravity.CENTER
        fpsP.add(a.tv("ACTUAL FPS", 10f, Pal.SUB), 2)
        fpsP.add(fpsBig)
        fpsP.add(fpsStatus.view, 0)
        fpsP.add(graph, 6, 1f)
        fpsP.add(fpsNote, 4)
        fpsP.add(logView, 6)
        body.add(fpsP, 0, 1.25f, h = LinearLayout.LayoutParams.MATCH_PARENT)

        // middle: monitors
        val mid = LinearLayout(a)
        mid.orientation = LinearLayout.VERTICAL
        val hz = a.panel("REFRESH RATE MONITOR")
        hz.add(hzNow.view, 4); hz.add(hzReq.view, 3); hz.add(hzAct.view, 3); hz.add(hzStat.view, 3); hz.add(hzModes, 3)
        mid.add(hz)
        val cpu = a.panel("CPU MONITOR")
        cpu.add(cpuUse.view, 4); cpu.add(cpuFreq.view, 3); cpu.add(cpuTemp.view, 3)
        mid.add(cpu, 6)
        val gpu = a.panel("GPU MONITOR")
        gpu.add(gpuUse.view, 4); gpu.add(gpuFreq.view, 3); gpu.add(gpuTemp.view, 3); gpu.add(gpuBoost.view, 3)
        mid.add(gpu, 6)
        val tmp = a.panel("TEMPERATURE")
        tmp.add(battTemp.view, 4)
        mid.add(tmp, 6)
        val sc1 = ScrollView(a)
        sc1.addView(mid)
        sc1.isVerticalScrollBarEnabled = false
        body.add(sc1, 0, 1f, h = LinearLayout.LayoutParams.MATCH_PARENT)
        (sc1.layoutParams as LinearLayout.LayoutParams).leftMargin = a.dp(8)

        // right: controls
        val ctl = LinearLayout(a)
        ctl.orientation = LinearLayout.VERTICAL
        val perf = a.panel("PERFORMANCE MODE")
        perf.add(Seg(a, listOf("OFF", "BALANCED", "PERFORMANCE"), prefs.getI("perf_mode", 2)) {
            prefs.setI("perf_mode", it)
            SfxHub.play(if (it == 2) Sfx.BOOST_ON else Sfx.CLICK)
            Engine.profileChanged()
        }.view, 6)
        perf.add(a.tv("FPS TARGET", 10f, Pal.SUB), 8)
        val fpsOpts = listOf(60, 90, 120)
        perf.add(Seg(a, fpsOpts.map { "$it FPS" }, fpsOpts.indexOf(prefs.getI("fps_target", 90)).coerceAtLeast(0)) {
            prefs.setI("fps_target", fpsOpts[it])
            graph.target = fpsOpts[it].toFloat()
            Engine.profileChanged()
        }.view, 3)
        perf.add(Tog(a, "Auto-apply when MLBB starts", prefs.getB("auto_apply", true)) { prefs.setB("auto_apply", it) }.view, 8)
        perf.add(Tog(a, "Close cached background apps", prefs.getB("bg_trim", false)) { prefs.setB("bg_trim", it); Engine.profileChanged() }.view, 6)
        perf.add(modeRow.view, 8)
        perf.add(appliedRow.view, 3)
        ctl.add(perf)

        val gp = a.panel("GPU PERFORMANCE")
        gp.add(Tog(a, "GPU BOOST", prefs.getB("gpu_boost", true)) { prefs.setB("gpu_boost", it); Engine.profileChanged() }.view, 6)
        gp.add(Seg(a, listOf("DEFAULT", "BALANCED", "PERFORMANCE"), prefs.getI("gpu_profile", 2)) {
            prefs.setI("gpu_profile", it); Engine.profileChanged()
        }.view, 6)
        val tgtRow = LinearLayout(a)
        tgtRow.orientation = LinearLayout.HORIZONTAL
        tgtRow.gravity = Gravity.CENTER_VERTICAL
        tgtRow.addView(a.tv("TARGET FREQUENCY", 11f, Pal.SUB), LinearLayout.LayoutParams(0, -2, 1f))
        tgtRow.addView(a.button("-", false) { stepGpu(-100) }, LinearLayout.LayoutParams(a.dp(40), -2))
        gpuTargetTxt.gravity = Gravity.CENTER
        tgtRow.addView(gpuTargetTxt, LinearLayout.LayoutParams(a.dp(80), -2))
        tgtRow.addView(a.button("+", false) { stepGpu(100) }, LinearLayout.LayoutParams(a.dp(40), -2))
        gp.add(tgtRow, 6)
        gp.add(a.tv("1200 MHz is a GPU clock. It is only attempted when this device exposes a writable GPU frequency file.", 9f, Pal.SUB), 4)
        ctl.add(gp, 6)

        val tp = a.panel("TOUCH RESPONSE")
        tp.add(Seg(a, listOf("FAST", "DEFAULT", "SLOW"), prefs.getI("touch", 1)) { prefs.setI("touch", it) }.view, 6)
        tp.add(touchRow.view, 6)
        ctl.add(tp, 6)

        val st = a.panel("SYSTEM")
        st.add(Tog(a, "SOUND EFFECTS", prefs.getB("sfx_on", true)) { prefs.setB("sfx_on", it) }.view, 6)
        st.add(Tog(a, "Haptic feedback", prefs.getB("haptic", true)) { prefs.setB("haptic", it); Pal.haptic = it }.view, 6)
        st.add(Tog(a, "Background watcher (notification)", prefs.getB("watcher", true)) {
            prefs.setB("watcher", it)
            if (it) startWatcher() else a.stopService(Intent(a, WatcherService::class.java))
        }.view, 6)
        ctl.add(st, 6)

        val btns = LinearLayout(a)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.addView(a.button("APPLY NOW", true) { Engine.applyNow() }, LinearLayout.LayoutParams(0, -2, 1f))
        btns.addView(a.button("RESTORE", false) { Engine.restoreNow() }, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = a.dp(6) })
        btns.addView(a.button("LAUNCH MLBB", false) { launchGame() }, LinearLayout.LayoutParams(0, -2, 1.2f).also { it.leftMargin = a.dp(6) })
        ctl.add(btns, 8)

        val sc2 = ScrollView(a)
        sc2.addView(ctl)
        sc2.isVerticalScrollBarEnabled = false
        body.add(sc2, 0, 1.3f, h = LinearLayout.LayoutParams.MATCH_PARENT)
        (sc2.layoutParams as LinearLayout.LayoutParams).leftMargin = a.dp(8)

        shizukuChip.setOnClickListener { onShizukuTap() }
        graph.target = prefs.getI("fps_target", 90).toFloat()
        update()
    }

    private fun View0(): android.view.View = android.view.View(a)

    fun startWatcher() {
        try { a.startForegroundService(Intent(a, WatcherService::class.java)) } catch (t: Throwable) { Engine.log("Could not start watcher: " + (t.message ?: "")) }
    }

    private fun stepGpu(d: Int) {
        val v = (prefs.getI("gpu_mhz", 1200) + d).coerceIn(300, 1500)
        prefs.setI("gpu_mhz", v)
        Engine.profileChanged()
        update()
    }

    private fun launchGame() {
        val i = a.packageManager.getLaunchIntentForPackage(Sampler.PKG)
        if (i == null) {
            SfxHub.play(Sfx.WARNING)
            Toast.makeText(a, "Mobile Legends is not installed", Toast.LENGTH_SHORT).show()
        } else {
            SfxHub.play(Sfx.GAME_LAUNCH)
            a.startActivity(i)
        }
    }

    private fun onShizukuTap() {
        when (Engine.shizuku) {
            ShizukuState.PERMISSION_REQUIRED -> ShizukuBridge.requestPermission()
            ShizukuState.DISCONNECTED -> {
                val i = a.packageManager.getLaunchIntentForPackage(ShizukuBridge.PKG)
                if (i != null) a.startActivity(i)
                else { SfxHub.play(Sfx.WARNING); Toast.makeText(a, "Install and start Shizuku first", Toast.LENGTH_LONG).show() }
            }
            else -> Engine.kick()
        }
    }

    private fun chip(t: TextView, text: String, color: Int) {
        t.text = text
        t.background = a.bg(Color.argb(60, Color.red(color), Color.green(color), Color.blue(color)), 8, color, 1)
        t.setTextColor(color)
    }

    fun update() {
        val s = Engine.shizuku
        val ok = s == ShizukuState.CONNECTED
        when (s) {
            ShizukuState.CONNECTED -> chip(shizukuChip, "SHIZUKU  CONNECTED", Pal.GREEN)
            ShizukuState.PERMISSION_REQUIRED -> chip(shizukuChip, "SHIZUKU  PERMISSION REQUIRED (TAP)", Pal.AMBER)
            ShizukuState.UNSUPPORTED -> chip(shizukuChip, "SHIZUKU  UNSUPPORTED", Pal.RED)
            ShizukuState.DISCONNECTED -> chip(shizukuChip, "SHIZUKU  DISCONNECTED (TAP)", Pal.RED)
        }
        if (!ok) chip(gameChip, "GAME  " + need, Pal.AMBER)
        else if (!Engine.fgKnown) chip(gameChip, "GAME  DETECTION UNAVAILABLE", Pal.AMBER)
        else if (Engine.gameFg) chip(gameChip, "GAME  MLBB DETECTED", Pal.GREEN)
        else chip(gameChip, "GAME  IDLE", Pal.SUB)

        // FPS
        val tgt = prefs.getI("fps_target", 90)
        fpsTarget.set("$tgt FPS")
        val fps = Engine.fps
        if (fps >= 0f) { shownFps += (fps - shownFps) * 0.4f; fpsBig.text = Math.round(shownFps).toString() }
        else { shownFps = 0f; fpsBig.text = "-" }
        val stTxt: String
        var stCol = Pal.SUB
        if (!ok) stTxt = need
        else if (!Engine.gameFg) stTxt = "IDLE (MLBB NOT RUNNING)"
        else if (fps < 0f) { stTxt = "UNAVAILABLE"; stCol = Pal.AMBER }
        else if (fps >= tgt * 0.92f) { stTxt = "ACTIVE"; stCol = Pal.GREEN }
        else { stTxt = "LIMITED"; stCol = Pal.AMBER }
        fpsStatus.set(stTxt, stCol)
        fpsNote.text = if (Engine.gameFg && fps >= 0f && fps < tgt * 0.92f)
            "MLBB is rendering below the target. SanjuSystemX cannot raise a game's internal FPS cap."
        else if (Engine.fpsNote.isNotEmpty()) Engine.fpsNote else ""
        if (Engine.sampleSeq != lastSeq) { lastSeq = Engine.sampleSeq; graph.push(if (Engine.gameFg) Engine.fps else -1f) }
        logView.text = Engine.logTail(5).joinToString("\n")

        // Refresh rate
        val cur = if (Engine.hzActual > 0f) Engine.hzActual else DisplayCtl.current(a)
        hzNow.set(if (cur > 0f) Math.round(cur).toString() + " Hz" else "UNAVAILABLE")
        hzReq.set(if (Engine.hzReq > 0) Engine.hzReq.toString() + " Hz" else "-")
        hzAct.set(if (cur > 0f) Math.round(cur).toString() + " Hz" else "UNAVAILABLE")
        val hs = Engine.hzStatus
        hzStat.set(hs, if (hs == "APPLIED") Pal.GREEN else if (hs.startsWith("NOT APPLIED") || hs.startsWith("UNSUPPORTED") || hs.startsWith("SHIZUKU")) Pal.AMBER else Pal.SUB)
        val rates = DisplayCtl.rates(a)
        hzModes.text = "SUPPORTED MODES: " + (if (rates.isEmpty()) "UNKNOWN" else rates.joinToString(" / ") + " Hz")

        // CPU / GPU / temps
        cpuUse.set(if (!ok) need else if (Engine.cpuPct >= 0f) Math.round(Engine.cpuPct).toString() + " %" else "UNAVAILABLE")
        cpuFreq.set(if (!ok) need else if (Engine.cpuMhz > 0) Engine.cpuMhz.toString() + " MHz (peak core)" else "UNAVAILABLE")
        cpuTemp.set(if (!ok) need else if (Engine.cpuTemp >= 0f) String.format("%.1f C", Engine.cpuTemp) else "UNAVAILABLE")
        gpuUse.set(if (!ok) need else if (Engine.gpuPct >= 0f) Math.round(Engine.gpuPct).toString() + " %" else "UNSUPPORTED")
        gpuFreq.set(if (!ok) need else if (Engine.gpuMhz > 0) Engine.gpuMhz.toString() + " MHz" else "UNSUPPORTED")
        gpuTemp.set(if (!ok) need else if (Engine.gpuTemp >= 0f) String.format("%.1f C", Engine.gpuTemp) else "UNAVAILABLE")
        val gs = if (!ok) need else if (Engine.gpuStatus != "NOT REQUESTED") Engine.gpuStatus else if (Engine.gpuProbed && !Engine.gpuSupported) "UNSUPPORTED ON THIS DEVICE" else "READY"
        gpuBoost.set(gs, if (gs.startsWith("APPLIED")) Pal.GREEN else if (gs.startsWith("READY")) Pal.SUB else Pal.AMBER)
        battTemp.set(if (Engine.battTemp >= 0f) String.format("%.1f C", Engine.battTemp) else "UNAVAILABLE")
        modeRow.set(if (!ok) need else Engine.modeStatus, Pal.SUB)
        touchRow.set("UNSUPPORTED", Pal.AMBER)
        appliedRow.set(if (Engine.applied) "APPLIED (" + Engine.appliedBy + ")" else "NOT APPLIED", if (Engine.applied) Pal.GREEN else Pal.SUB)
        gpuTargetTxt.text = prefs.getI("gpu_mhz", 1200).toString() + " MHz"
    }
}
