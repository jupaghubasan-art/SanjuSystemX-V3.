package com.sanju.systemx.resolution

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display

/** Reads the real display state from Android. Nothing here is assumed or faked. */
object DisplayCtl {
    private fun disp(ctx: Context): Display? = try {
        (ctx.applicationContext.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
    } catch (t: Throwable) { null }

    /** Refresh rate of the active display mode in Hz, or -1 if unreadable. */
    fun current(ctx: Context): Float = try { disp(ctx)?.refreshRate ?: -1f } catch (t: Throwable) { -1f }

    /** Distinct refresh rates the panel reports, ascending. */
    fun rates(ctx: Context): List<Int> {
        val d = disp(ctx) ?: return emptyList()
        return try {
            d.supportedModes.map { Math.round(it.refreshRate) }.distinct().sorted()
        } catch (t: Throwable) { emptyList() }
    }
}
