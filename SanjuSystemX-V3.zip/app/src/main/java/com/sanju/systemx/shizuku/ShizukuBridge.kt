package com.sanju.systemx.shizuku

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

enum class ShizukuState { CONNECTED, DISCONNECTED, PERMISSION_REQUIRED, UNSUPPORTED }

class ShellResult(val code: Int, val out: String) {
    val ok: Boolean get() = code == 0
}

object ShizukuBridge {
    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 4242
    @Volatile private var noNewProcess = false

    fun isInstalled(ctx: Context): Boolean =
        try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (t: Throwable) { false }

    fun state(): ShizukuState {
        if (noNewProcess) return ShizukuState.UNSUPPORTED
        return try {
            if (Shizuku.isPreV11()) ShizukuState.UNSUPPORTED
            else if (!Shizuku.pingBinder()) ShizukuState.DISCONNECTED
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) ShizukuState.CONNECTED
            else ShizukuState.PERMISSION_REQUIRED
        } catch (t: Throwable) {
            ShizukuState.DISCONNECTED
        }
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQ) } catch (t: Throwable) { }
    }

    private val newProcessMethod by lazy {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        m
    }

    /** Runs a command with shell privileges through Shizuku. Never throws. */
    fun exec(cmd: Array<String>, timeoutMs: Long = 5000L): ShellResult {
        val st = state()
        if (st != ShizukuState.CONNECTED) return ShellResult(-2, "SHIZUKU REQUIRED ($st)")
        var proc: Process? = null
        try {
            val p = newProcessMethod.invoke(null, cmd, null, null) as Process
            proc = p
            val killer = Thread {
                try { Thread.sleep(timeoutMs); p.destroy() } catch (e: InterruptedException) { }
            }
            killer.isDaemon = true
            killer.start()
            val err = StringBuilder()
            val errT = Thread {
                try { err.append(p.errorStream.bufferedReader().readText()) } catch (e: Throwable) { }
            }
            errT.isDaemon = true
            errT.start()
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            errT.join(500)
            killer.interrupt()
            return ShellResult(code, (out + err).trim())
        } catch (e: NoSuchMethodException) {
            noNewProcess = true
            return ShellResult(-3, "UNSUPPORTED: this Shizuku version has no shell API")
        } catch (t: Throwable) {
            return ShellResult(-1, "SHELL ERROR: " + (t.cause?.message ?: t.message ?: t.javaClass.simpleName))
        } finally {
            try { proc?.destroy() } catch (t: Throwable) { }
        }
    }

    fun sh(script: String, timeoutMs: Long = 5000L): ShellResult =
        exec(arrayOf("sh", "-c", script), timeoutMs)
}
