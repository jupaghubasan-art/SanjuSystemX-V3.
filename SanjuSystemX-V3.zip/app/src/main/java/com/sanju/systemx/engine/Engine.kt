package com.sanju.systemx.engine

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.HandlerThread
import com.sanju.systemx.monitor.Calc
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.optimizer.Applier
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Process-wide engine: detects MLBB, applies/restores the profile, samples real metrics.
 * All work happens on one background thread. The UI only reads the @Volatile fields.
 * Metrics that cannot be read stay at -1 and the UI shows UNAVAILABLE / UNSUPPORTED.
 */
object Engine {
    const val PKG = Sampler.PKG

    private var app: Context? = null
    private var prefs: Prefs? = null
    private var ht: HandlerThread? = null
    private var h: Handler? = null
    private val calc = Calc()

    @Volatile var uiVisible = false
    @Volatile var watcherActive = false

    // ---- state read by the UI ----
    @Volatile var shizuku = ShizukuState.DISCONNECTED
    @Volatile var gameFg = false
    @Volatile var fgKnown = true
    @Volatile var fps = -1f
    @Volatile var fpsNote = ""
    @Volatile var hzActual = -1f
    @Volatile var hzReq = 0
    @Volatile var hzStatus = "NOT REQUESTED"
    @Volatile var modeStatus = "NOT REQUESTED"
    @Volatile var gpuStatus = "NOT REQUESTED"
    @Volatile var trimStatus = "NOT REQUESTED"
    @Volatile var cpuPct = -1f
    @Volatile var cpuMhz = -1
    @Volatile var cpuTemp = -1f
    @Volatile var gpuPct = -1f
    @Volatile var gpuMhz = -1
    @Volatile var gpuTemp = -1f
    @Volatile var battTemp = -1f
    @Volatile var applied = false
    @Volatile var appliedBy = ""
    @Volatile var sampleSeq = 0
    @Volatile var gpuSupported = false
    @Volatile var gpuProbed = false

    private var gpu: Sampler.GpuInfo? = null
    private var layers: List<String> = emptyList()
    private var layerIdx = 0
    private var layerAt = 0L
    private var zeroFps = 0
    private var miss = 0
    private var fgBlank = 0
    private var cycle = 0L
    private var recoveryDone = false
    private val logBuf = ArrayList<String>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun init(ctx: Context) {
        if (h != null) return
        app = ctx.applicationContext
        prefs = Prefs.get(ctx)
        val t = HandlerThread("sx-engine")
        t.start()
        ht = t
        h = Handler(t.looper)
        log("ENGINE STARTED")
        kick()
    }

    private val tickRun = object : Runnable {
        override fun run() {
            val next = try { tick() } catch (t: Throwable) { log("ENGINE ERROR: " + (t.message ?: t.javaClass.simpleName)); 3000L }
            h?.postDelayed(this, next)
        }
    }

    /** Run a tick as soon as possible. */
    fun kick() {
        val hh = h ?: return
        hh.removeCallbacks(tickRun)
        hh.post(tickRun)
    }

    fun log(msg: String) {
        synchronized(logBuf) {
            logBuf.add(timeFmt.format(Date()) + "  " + msg)
            while (logBuf.size > 40) logBuf.removeAt(0)
        }
    }

    fun logTail(n: Int): List<String> = synchronized(logBuf) { logBuf.takeLast(n) }

    // ---- UI actions ----
    fun applyNow() { h?.post { applyProfile(false) } }
    fun restoreNow() { h?.post { doRestore("MANUAL RESTORE") } }
    fun profileChanged() {
        h?.post {
            if (gameFg && applied && appliedBy == "AUTO") { doRestore("PROFILE CHANGED"); applyProfile(true) }
            else if (gameFg && !applied) applyProfile(true)
        }
    }
    fun refreshGpuProbe() { h?.post { gpuProbed = false } ; kick() }

    // ---- main loop ----
    private fun tick(): Long {
        val ctx = app ?: return 5000L
        val p = prefs ?: return 5000L
        shizuku = ShizukuBridge.state()
        hzActual = DisplayCtl.current(ctx)
        battTemp = batteryTemp(ctx)

        if (shizuku != ShizukuState.CONNECTED) {
            gameFg = false
            fps = -1f; cpuPct = -1f; cpuMhz = -1; cpuTemp = -1f; gpuPct = -1f; gpuMhz = -1; gpuTemp = -1f
            gpuProbed = false
            calc.resetCpu(); calc.resetFps()
            return if (uiVisible) 1500L else 8000L
        }
        if (!uiVisible && !watcherActive && !gameFg) return 20000L

        if (!gpuProbed) {
            gpu = Sampler.probeGpu()
            gpuSupported = gpu != null && gpu!!.writableMin && gpu!!.avail.isNotEmpty()
            gpuProbed = true
            log(if (gpu == null) "GPU: no readable GPU interface" else "GPU interface found" + (if (gpuSupported) " (writable)" else " (read-only)"))
        }

        cycle++
        val full = uiVisible || gameFg
        if (!full) {
            val raw = Sampler.sampleFg()
            evalFg(raw?.fg)
            return 3000L
        }
        val checkFg = !gameFg || cycle % 3L == 0L
        if (gameFg && fps >= 0f && layers.isEmpty()) discoverLayers()
        if (gameFg && layers.isEmpty() && System.currentTimeMillis() - layerAt > 4000L) discoverLayers()
        val layer = if (gameFg && layers.isNotEmpty()) layers[layerIdx % layers.size] else ""
        val raw = Sampler.sampleFull(gpu?.dir ?: "", layer, checkFg)
        if (raw == null) return 1500L
        updateMetrics(raw)
        evalFg(raw.fg)
        sampleSeq++
        return 1000L
    }

    private fun updateMetrics(raw: com.sanju.systemx.monitor.Raw) {
        cpuPct = calc.cpu(raw.stat)
        val mx = raw.freqs.maxOrNull()
        cpuMhz = if (mx == null) -1 else (mx / 1000L).toInt()
        var ct = -1f
        var gt = -1f
        for ((id, tv) in raw.temps) {
            val type = raw.types[id] ?: continue
            val t = Sampler.normTemp(tv)
            if (t < -20f || t > 150f) continue
            if (Sampler.isGpuZone(type)) { if (t > gt) gt = t }
            else if (Sampler.isCpuZone(type)) { if (t > ct) ct = t }
        }
        cpuTemp = ct
        gpuTemp = gt
        val gf = raw.gpuF?.trim()?.toLongOrNull()
        gpuMhz = if (gf == null) -1 else Sampler.rawToMhz(gf)
        gpuPct = parseGpuBusy(raw.gpuB)

        if (gameFg) {
            val f = calc.fps(raw.fps)
            fps = f
            if (f < 0f) {
                fpsNote = "No frame data from SurfaceFlinger on this device"
                zeroFps++
            } else if (f == 0f) {
                fpsNote = "No new frames"
                zeroFps++
            } else { fpsNote = ""; zeroFps = 0 }
            if (zeroFps >= 3 && layers.size > 1) { layerIdx++; zeroFps = 0; calc.resetFps() }
        } else {
            fps = -1f
            fpsNote = ""
        }
    }

    private fun parseGpuBusy(lines: List<String>): Float {
        for (l in lines) {
            val t = l.trim()
            if (t.contains("%")) {
                val v = t.replace("%", "").trim().toFloatOrNull()
                if (v != null) return v.coerceIn(0f, 100f)
            }
        }
        for (l in lines) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size == 2) {
                val a = p[0].toLongOrNull()
                val b = p[1].toLongOrNull()
                if (a != null && b != null && b > 0L) return (a * 100f / b).coerceIn(0f, 100f)
            }
        }
        return -1f
    }

    private fun discoverLayers() {
        layerAt = System.currentTimeMillis()
        val r = ShizukuBridge.sh("dumpsys SurfaceFlinger --list 2>/dev/null | grep '" + PKG + "'")
        val all = r.out.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("Background for") && !it.contains("Bounds for") }
        val sv = all.filter { it.startsWith("SurfaceView[") }
        layers = if (sv.isNotEmpty()) sv + all.filter { !it.startsWith("SurfaceView[") } else all
        layerIdx = 0
        if (layers.isNotEmpty()) log("FPS source: " + layers[0].take(48))
    }

    private fun evalFg(txt: String?) {
        if (txt == null) return
        if (txt.isBlank()) {
            fgBlank++
            if (fgBlank >= 5) fgKnown = false
            return
        }
        fgBlank = 0
        fgKnown = true
        val inGame = txt.contains(PKG)
        val p = prefs
        if (inGame) {
            miss = 0
            if (!gameFg) onGameStart()
        } else {
            if (gameFg) {
                miss++
                if (miss >= 2) onGameStop()
            } else if (!recoveryDone) {
                recoveryDone = true
                if (p != null && !applied && Applier.hasJournal(p)) doRestore("CRASH RECOVERY")
            }
        }
        recoveryDone = true
    }

    private fun onGameStart() {
        gameFg = true
        miss = 0
        layers = emptyList(); layerIdx = 0; layerAt = 0L; zeroFps = 0
        calc.resetFps()
        log("MLBB DETECTED")
        val p = prefs ?: return
        if (p.getB("auto_apply", true) && p.getI("perf_mode", 2) != 0) applyProfile(true)
        else log("AUTO-APPLY OFF or PERFORMANCE MODE OFF: monitoring only")
        kick()
    }

    private fun onGameStop() {
        gameFg = false
        miss = 0
        fps = -1f
        log("MLBB CLOSED")
        if (applied && appliedBy == "AUTO") doRestore("MLBB EXITED")
    }

    private fun applyProfile(auto: Boolean) {
        val ctx = app ?: return
        val p = prefs ?: return
        if (shizuku != ShizukuState.CONNECTED) { log("SHIZUKU REQUIRED: nothing applied"); hzStatus = "SHIZUKU REQUIRED"; return }
        val mode = p.getI("perf_mode", 2)
        if (mode == 0) { log("PERFORMANCE MODE OFF: nothing applied"); return }
        val target = p.getI("fps_target", 90)
        log("APPLYING PROFILE (" + (if (mode == 2) "PERFORMANCE" else "BALANCED") + ", " + target + " FPS target)")
        val r = Applier.apply(ctx, p, gpu, mode, target)
        hzReq = r.hzReq
        hzStatus = r.hzStatus
        modeStatus = r.modeStatus
        gpuStatus = r.gpuStatus
        trimStatus = r.trimStatus
        for (l in r.lines) log(l)
        applied = true
        appliedBy = if (auto) "AUTO" else "MANUAL"
        h?.postDelayed({ verifyHz() }, 1800L)
    }

    private fun verifyHz() {
        val ctx = app ?: return
        if (!applied || hzReq <= 0 || !hzStatus.startsWith("REQUESTED")) return
        val a = DisplayCtl.current(ctx)
        hzActual = a
        if (a >= hzReq - 1.5f) {
            hzStatus = "APPLIED"
            log("DISPLAY: " + hzReq + " Hz APPLIED (actual " + Math.round(a) + " Hz)")
        } else {
            hzStatus = "NOT APPLIED (device stayed at " + Math.round(a) + " Hz)"
            log("DISPLAY: requested " + hzReq + " Hz but actual is " + Math.round(a) + " Hz. This device ignores the system request")
        }
    }

    private fun doRestore(reason: String) {
        val p = prefs ?: return
        log(reason + ": RESTORING")
        val lines = try { Applier.restore(p) } catch (t: Throwable) { listOf("RESTORE ERROR: " + (t.message ?: "")) }
        for (l in lines) log(l)
        applied = false
        appliedBy = ""
        hzReq = 0
        hzStatus = "NOT REQUESTED"
        modeStatus = "NOT REQUESTED"
        gpuStatus = "NOT REQUESTED"
        trimStatus = "NOT REQUESTED"
    }

    private fun batteryTemp(ctx: Context): Float {
        return try {
            val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if (t < 0) -1f else t / 10f
        } catch (e: Throwable) { -1f }
    }
}
