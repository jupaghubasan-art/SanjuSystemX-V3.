package com.sanju.systemx.optimizer

import android.content.Context
import android.os.Build
import com.sanju.systemx.monitor.Sampler
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge

class ApplyResult {
    var hzReq = 0
    var hzStatus = "NOT REQUESTED"
    var modeStatus = "NOT REQUESTED"
    var gpuStatus = "NOT REQUESTED"
    var trimStatus = "NOT REQUESTED"
    val lines = ArrayList<String>()
}

/**
 * Applies the Game Space profile through Shizuku and keeps a restore journal in SharedPreferences.
 * Every original value is saved BEFORE it is changed, so restore works even after a crash.
 */
object Applier {
    private const val PKG = Sampler.PKG
    private const val JOURNAL = "journal"
    private val BAD = listOf("error", "usage", "unknown", "exception", "invalid", "not found", "denied")

    // ---- journal ----
    private fun load(prefs: Prefs): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        for (l in prefs.getS(JOURNAL, "").lines()) {
            val i = l.indexOf('=')
            if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
        }
        return m
    }

    private fun save(prefs: Prefs, m: Map<String, String>) {
        prefs.setSNow(JOURNAL, m.entries.joinToString("\n") { it.key + "=" + it.value })
    }

    fun hasJournal(prefs: Prefs): Boolean = load(prefs).isNotEmpty()

    private fun saveOnce(prefs: Prefs, key: String, value: String) {
        val m = load(prefs)
        if (!m.containsKey(key)) { m[key] = value; save(prefs, m) }
    }

    // ---- helpers ----
    private fun okGame(r: com.sanju.systemx.shizuku.ShellResult): Boolean =
        r.code == 0 && BAD.none { r.out.contains(it, true) }

    private fun setGameMode(mode: String): Boolean {
        if (okGame(ShizukuBridge.sh("cmd game set --mode $mode $PKG 2>&1"))) return true
        return okGame(ShizukuBridge.sh("cmd game mode $mode $PKG 2>&1"))
    }

    private fun getSetting(key: String): String =
        ShizukuBridge.sh("settings get system $key 2>/dev/null").out.trim().ifEmpty { "null" }

    private fun restoreSetting(key: String, v: String): Boolean {
        val cmd = if (v == "null") "settings delete system $key" else "settings put system $key $v"
        return ShizukuBridge.sh(cmd).code == 0
    }

    // ---- apply ----
    fun apply(ctx: Context, prefs: Prefs, gpu: Sampler.GpuInfo?, mode: Int, fpsTarget: Int): ApplyResult {
        val res = ApplyResult()

        // 1) Refresh rate (system min/peak refresh rate, the standard AOSP keys)
        val rates = DisplayCtl.rates(ctx)
        if (rates.isEmpty()) {
            res.hzStatus = "UNSUPPORTED (cannot read display modes)"
        } else {
            val req = if (mode == 2) rates.last() else (rates.filter { it >= fpsTarget }.minOrNull() ?: rates.last())
            res.hzReq = req
            saveOnce(prefs, "sys.min_refresh_rate", getSetting("min_refresh_rate"))
            saveOnce(prefs, "sys.peak_refresh_rate", getSetting("peak_refresh_rate"))
            val v = req.toString() + ".0"
            val a = ShizukuBridge.sh("settings put system min_refresh_rate $v")
            val b = ShizukuBridge.sh("settings put system peak_refresh_rate $v")
            if (a.code == 0 && b.code == 0) {
                res.hzStatus = "REQUESTED"
                res.lines.add("$req Hz REQUESTED (verifying...)")
            } else {
                res.hzStatus = "NOT APPLIED (command failed)"
                res.lines.add("Refresh-rate command failed: " + (if (a.code != 0) a.out else b.out))
            }
        }

        // 2) Game Mode hint (Android 12+), PERFORMANCE mode only
        if (mode == 2) {
            if (Build.VERSION.SDK_INT < 31) {
                res.modeStatus = "UNSUPPORTED (needs Android 12+)"
            } else {
                saveOnce(prefs, "game.mode", "standard")
                if (setGameMode("performance")) {
                    res.modeStatus = "ACCEPTED BY SYSTEM"
                    res.lines.add("Game Mode: PERFORMANCE accepted (effect depends on the game)")
                } else {
                    res.modeStatus = "NOT APPLIED (system rejected it)"
                    res.lines.add("Game Mode command was rejected by this device")
                }
            }
        }

        // 3) GPU frequency floor, only if the device exposes a writable interface
        val boost = prefs.getB("gpu_boost", true)
        val profile = prefs.getI("gpu_profile", 2)
        if (boost && profile != 0) {
            if (gpu == null || !gpu.writableMin || gpu.avail.isEmpty()) {
                res.gpuStatus = "UNSUPPORTED ON THIS DEVICE"
                res.lines.add("GPU boost: no writable GPU frequency interface (normal for non-root)")
            } else {
                val targetMhz = if (profile == 2) prefs.getI("gpu_mhz", 1200) else Sampler.rawToMhz(gpu.avail[gpu.avail.size / 2])
                val cap = if (gpu.maxF > 0) gpu.maxF else gpu.avail.last()
                val pick = gpu.avail.filter { it <= cap }.minByOrNull { Math.abs(Sampler.rawToMhz(it) - targetMhz) }
                if (pick == null) {
                    res.gpuStatus = "NOT APPLIED (no usable frequency)"
                } else {
                    saveOnce(prefs, "gpu.min", gpu.dir + "|" + gpu.minF)
                    ShizukuBridge.sh("echo $pick > ${gpu.dir}/min_freq")
                    val now = ShizukuBridge.sh("cat ${gpu.dir}/min_freq").out.trim().toLongOrNull()
                    if (now == pick) {
                        res.gpuStatus = "APPLIED (min " + Sampler.rawToMhz(pick) + " MHz)"
                        res.lines.add("GPU min frequency set to " + Sampler.rawToMhz(pick) + " MHz")
                    } else {
                        res.gpuStatus = "NOT APPLIED (kernel refused)"
                        res.lines.add("GPU write was refused by the kernel")
                    }
                }
            }
        }

        // 4) Optional background trim (cached processes only), PERFORMANCE mode only
        if (mode == 2 && prefs.getB("bg_trim", false)) {
            val r = ShizukuBridge.sh("am kill-all")
            res.trimStatus = if (r.code == 0) "DONE (cached apps closed)" else "NOT APPLIED"
            res.lines.add("Background trim: " + res.trimStatus)
        }
        return res
    }

    // ---- restore ----
    fun restore(prefs: Prefs): List<String> {
        val j = load(prefs)
        if (j.isEmpty()) return listOf("NOTHING TO RESTORE")
        val lines = ArrayList<String>()
        val remaining = LinkedHashMap<String, String>()
        for ((k, v) in j) {
            val ok = when {
                k == "sys.min_refresh_rate" -> restoreSetting("min_refresh_rate", v)
                k == "sys.peak_refresh_rate" -> restoreSetting("peak_refresh_rate", v)
                k == "game.mode" -> setGameMode(v)
                k == "gpu.min" -> {
                    val p = v.split('|')
                    p.size == 2 && p[1].toLongOrNull() != null && p[1].toLong() > 0 &&
                        ShizukuBridge.sh("echo ${p[1]} > ${p[0]}/min_freq").code == 0
                }
                else -> true
            }
            if (ok) lines.add("RESTORED $k") else { remaining[k] = v; lines.add("RESTORE FAILED $k (will retry)") }
        }
        save(prefs, remaining)
        return lines
    }
}
