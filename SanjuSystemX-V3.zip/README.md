# SanjuSystemX V3 (Game Space)

Shizuku-powered gaming HUD for Mobile Legends (`com.mobile.legends`). Package: `com.sanju.systemx`.

## Build
GitHub: push the files (or this zip) to `main` -> Actions -> *Build SanjuSystemX APK* -> download the artifact.
Local: `gradle assembleDebug assembleRelease` -> `app/build/outputs/apk/debug/app-debug.apk`

## What is real, what is not
| Feature | How | Honest status |
|---|---|---|
| Shizuku status | binder + permission check | CONNECTED / DISCONNECTED / PERMISSION REQUIRED / UNSUPPORTED |
| MLBB detection | shell `dumpsys` foreground check via Shizuku | needs Shizuku; shows "DETECTION UNAVAILABLE" if the OS prints nothing |
| Refresh rate | system `min_refresh_rate` / `peak_refresh_rate` | REQUESTED vs ACTUAL (read from Android) is always shown. Some phones ignore it: shown as NOT APPLIED |
| FPS target 60/90/120 | picks the display rate and is compared with measured FPS | cannot raise a game's internal FPS cap |
| Actual FPS | SurfaceFlinger frame timestamps of the MLBB layer | shows UNAVAILABLE when the device gives no data. Never invented |
| CPU usage/freq/temp | /proc/stat, cpufreq, thermal zones (via Shizuku) | UNAVAILABLE if unreadable |
| GPU usage/freq/temp | read-only vendor files (Adreno kgsl, devfreq) | UNSUPPORTED if not exposed |
| GPU boost / 1200 MHz | writes `min_freq` ONLY if the file is writable and the kernel accepts it | on most phones: UNSUPPORTED ON THIS DEVICE (needs root) |
| Game Mode hint | `cmd game ... performance` (Android 12+) | "accepted by system"; effect depends on the game |
| Touch response | no Android control exists | always UNSUPPORTED |
| Restore | original values saved before changing, restored when MLBB exits | journal also restores after a crash |

## Notes
- Background watcher = foreground service + notification, needed to detect MLBB while the game is in front. After a reboot: start Shizuku, then open SanjuSystemX once.
- Intro: 5 s cinematic, tap to skip. Shizuku/system init starts immediately and does not wait for it.
- Sounds are original synthesized tones in `res/raw` (replace by same file name). They use `SoundPool` with no audio focus and never change volume.
- Icon: your Mangekyo image (`res/drawable-nodpi/ic_launcher_fg.png`).
